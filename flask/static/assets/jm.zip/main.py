from janome.tokenizer import Tokenizer

t = Tokenizer()
def hello_world(request):
    global t
    ret=""
    if request.method=="POST":
    
        if 'speech' in request.json:
            target=request.json['speech'].translate(str.maketrans("\"\'\\/<>%`?;",'””￥_〈〉％”？；'))
            target=target.translate(str.maketrans(", ",'__'))
            for token in t.tokenize(target):
                ret+=token.part_of_speech.split(',')[0]+","
            return ret.strip(',')
    
        if 'surface' in request.json:
            target=request.json['surface'].translate(str.maketrans("\"\'\\/<>%`?;",'””￥_〈〉％”？；'))
            target=target.translate(str.maketrans(", ",'__'))
            for token in t.tokenize(target):
                ret+=token.surface+","
            return ret.strip(',')
    
        if 'phonetic' in request.json:
            target=request.json['phonetic'].translate(str.maketrans("\"\'\\/<>%`?;",'””￥_〈〉％”？；'))
            target=target.translate(str.maketrans(", ",'__'))
            for token in t.tokenize(target):
                ret+=token.phonetic+","
            return ret.strip(',')
    
    return request.method#"plz_access_by_POST<br><a href=\"\">back</a>"
